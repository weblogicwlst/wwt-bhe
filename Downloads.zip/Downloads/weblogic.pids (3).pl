#!/usr/bin/perl
  
$plist = `ps -U \$LOGNAME -o pid,pcpu,size,cmd|grep -i weblogic.Name|egrep -v grep`;
$CPU_THRESHOLD=10;
@prlist = split(/\n/ ,$plist );
print "PID    SERVER          CPU     SIZE      DOMAIN DIR
------ --------------- ------ ------  -----------------------------------
";
  
$i=0;
foreach $_ (@prlist){
        $x=$prlist[$i];
        $x=~ m/^\s*(\d+)\s.+\s+-Dweblogic\.Name=(\S+)\s+/ ||next;
        my @values = split(' ',$x);
        $pid=$1;
        $server=$2;
        $cpu=$values[1];
        if($cpu > $CPU_THRESHOLD)
        {
                #print "\n\nSUGGESTED ACTION:\n"
                #        . "-----------------\n"
                #       . "Use this command to trace threads on servers "
                #       . "with over $CPU_THRESHOLD% CPU usage:\n"
                #       . "/usr/bin/kill -3 " . $pid."\n";
        }
        $mem=int($values[2]/1024);
        $r = `/usr/bin/pwdx $pid 2>&1`;
        $r =~ s/^\d+://;
        $r =~ s/^\s+|\s$//g;
        print $pid, "\t", $server,"\t",$cpu,"\t",$mem,"M\t",$r,"\n";
        $i++;
}